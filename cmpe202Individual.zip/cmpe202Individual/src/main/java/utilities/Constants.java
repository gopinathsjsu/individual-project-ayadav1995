package utilities;

public class Constants {

	public static String masterCard = "MasterCard";
	public static String visa = "Visa";
	public static String discover = "Discover";
	public static String americanExpress = "AmericanExpress";
	public static String invalidCardType = "Invalid";
	public static String noError = "None";
	public static String error = "InvalidCardNumber";
	
	
	
	
}
