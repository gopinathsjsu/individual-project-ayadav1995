package cardHandlerTest;

import utilities.CsvHandler;
import utilities.FileParser;
import org.junit.Test;
import utilities.CsvHandler;
import utilities.FileParser;

import java.util.logging.FileHandler;

import static org.junit.Assert.assertFalse;

public class FileParserTest {
	
	String ipFilePath = "Test/Sample.csv";
	String opFilePath = "Test/SampleOutput.xml";

	@Test
    public void handleNumberTest() {
    	
		FileParser fp = new FileParser();

		
    }
}
